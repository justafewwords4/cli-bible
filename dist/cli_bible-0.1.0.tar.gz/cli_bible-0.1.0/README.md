# cli-bible

Leer la Biblia desde la línea de comandos.
